--[[
    Stance! — Skill Framework integration (player/skill_framework.lua)

    Owns everything that talks to the Skill Framework (SF) interface:
      * registering the core "Stance" skill,
      * the class-specialization dynamic modifier,
      * the per-skill additive effectiveness modifiers, and
      * syncing the active stance's name/attribute/description/tooltip onto
        the SF skill each tick.

    All SF API calls are funnelled through this module so the build-version
    risk lives in one place. It requires no engine modules directly; init.lua
    injects everything via .new(ctx), including the engine handles (I, util)
    and the init.lua helper locals this code used to close over.

    Construction (in init.lua, at this section's original position so every
    injected local is already defined):
        local skillFramework = require('scripts.stance.player.skill_framework').new({ ... })

    Behaviour is identical to the former init.lua locals. Public API:
        skillFramework.isSkillRegistered()      -> bool  (the internal flag)
        skillFramework.isClassBonusApplied()     -> bool
        skillFramework.registerSkill()
        skillFramework.applyClassBonus()
        skillFramework.refreshEffectivenessModifiers()
        skillFramework.syncToActiveStance()
        skillFramework.markUnregistered()        -- reset flags on load/reload
]]

local M = {}

function M.new(ctx)
    ctx = ctx or {}

    -- Engine handles + config (passed in directly).
    local I        = ctx.I
    local util     = ctx.util
    local config   = ctx.config
    local SKILL_ID = ctx.SKILL_ID

    -- init.lua helper locals (passed in directly — all defined before this
    -- module is constructed).
    local readSetting           = ctx.readSetting
    local debugLog              = ctx.debugLog
    local getStanceConfig       = ctx.getStanceConfig
    local formatStanceName      = ctx.formatStanceName
    local getCoreSkillLevel     = ctx.getCoreSkillLevel
    local getStanceLevel        = ctx.getStanceLevel
    local getStanceXp           = ctx.getStanceXp
    local effectivenessSkillBonus = ctx.effectivenessSkillBonus
    local xpForStanceLevel      = ctx.xpForStanceLevel
    local resolveStanceSkill    = ctx.resolveStanceSkill
    local perksEnabledForStance = ctx.perksEnabledForStance
    local integrationPresent    = ctx.integrationPresent
    -- Active stance id changes over time, so it is read through a getter.
    local getActiveStance       = ctx.getActiveStance
    local getSelf               = ctx.getSelf or function() return nil end
    local statAccess            = require('scripts.stance.player.stat_access')

    -- ── Module state (formerly init.lua file-level locals) ────────────────
    local skillRegistered = false
    local classBonusApplied = false
    local lastSkillSyncedName = nil
    local lastSkillSyncedAttribute = nil
    local lastSkillSyncedDescription = nil

    local function skillIsRegistered()
        return I.SkillFramework
            and I.SkillFramework.getSkillRecord
            and I.SkillFramework.getSkillRecord(SKILL_ID) ~= nil
    end

    local function registerSkill()
        if not readSetting('', 'enableSkillRegistration', true) then return false end
        if not I.SkillFramework then
            debugLog('Skill Framework not found — Stance skill will not appear.',
                'debugIntegrationMessages')
            return false
        end
        if skillIsRegistered() then
            skillRegistered = true
            return true
        end

        local specialization = I.SkillFramework.SPECIALIZATION
            and I.SkillFramework.SPECIALIZATION.Combat or nil

        I.SkillFramework.registerSkill(SKILL_ID, {
            name = config.defaultDisplayName,
            description = 'Stance reflects the form you currently hold. As you fight, cast, parry, barter, or reforge, the ACTIVE stance gains experience and levels on its own — and the core Stance skill gains half as much, leveling independently. Each stance is governed by a different attribute. Perks unlock from the core Stance skill level (25/50/75/100) across every stance, while each stance\'s own level raises its effectiveness.',
            attribute = config.defaultAttribute,
            specialization = specialization,
            startLevel = config.startLevel,
            maxLevel = config.maxLevel,
            skillGain = { [1] = 1.0 },
            statsWindowProps = {
                subsection = 'Stance',
                shortenedName = config.defaultDisplayName,
                visible = true,
            },
            icon = {
                bgr = 'icons/SkillFramework/combat_blank.dds',
                bgrColor = util.color.rgb(1, 1, 1),
            },
        })

        if readSetting('Progression', 'enableRaceBonuses', true) then
            -- Small uniform bonus across all races — Stance applies to
            -- everyone; specialised builds still come from per-stance grind.
            local races = {
                'imperial', 'breton', 'redguard', 'nord', 'dunmer',
                'altmer', 'bosmer', 'orc', 'khajiit', 'argonian',
                'T_Bm_Naga', 'T_Yne_Ynesai', 'T_Sky_Reachman', 'T_Pya_SeaElf',
            }
            for _, r in ipairs(races) do
                pcall(I.SkillFramework.registerRaceModifier, SKILL_ID, r, 5)
            end
        end

        debugLog('Stance skill registered.', 'debugIntegrationMessages')
        skillRegistered = true

        return true
    end

    local function getClassSpecializationBonus()
        if not readSetting('Progression', 'enableClassBonus', true) then return 0 end
        return config.classBonus or 0
    end

    local function applyClassBonus()
        if classBonusApplied then return end
        if not (I.SkillFramework and I.SkillFramework.registerDynamicModifier and skillIsRegistered()) then
            return
        end
        pcall(I.SkillFramework.registerDynamicModifier, SKILL_ID,
            'Stance_ClassSpecializationBonus', getClassSpecializationBonus)
        classBonusApplied = true
        debugLog('Class specialisation bonus modifier registered.',
            'debugIntegrationMessages')
    end

    -- ── Per-skill additive effectiveness modifiers ────────────────────────
    --
    -- The effectiveness bonus raises the skill tied to the active stance by a
    -- level-scaled amount (+2..+20). Two delivery paths, by skill kind:
    --
    --   VANILLA skills (longblade, shortblade, speechcraft, ...): applied via
    --     the engine-native skill `.modifier` field. Skill Framework's
    --     registerDynamicModifier only governs SF's own custom skills, so the
    --     previous version's getSkillRecord('longblade') check always failed
    --     and NO vanilla effectiveness bonus was ever applied — this is the
    --     core of the "additive skill bonuses not working" report.
    --
    --   MODDED SF skills (throwing, staves_staves, fishing_skill,
    --     mining_skill): these ARE SF-registered, so registerDynamicModifier
    --     works and we keep using it.
    --
    -- For vanilla skills we track our own per-skill contribution and adjust
    -- only our portion (delta accounting), exactly like the perk skill/attr
    -- contributions, so we stack cleanly with fortify/drain and never stomp
    -- another system's modifier.
    local effectivenessModifiersRegistered = {}   -- modded SF skills only
    local effVanillaContrib = {}                   -- [skillId] = our applied points

    local VANILLA_EFF_SKILLS = {
        'longblade', 'shortblade', 'bluntweapon', 'axe', 'spear',
        'marksman', 'handtohand', 'block', 'armorer', 'security', 'speechcraft',
        'mysticism',
    }
    local MODDED_EFF_SKILLS = {
        throwing      = 'throwing',
        staves        = 'staves_staves',
        fishing       = 'fishing_skill',
        simplymining  = 'mining_skill',
    }

    local function currentEffectiveBonusSkill()
        if not getActiveStance() then return nil, 0 end
        if not readSetting('', 'enabled', true) then return nil, 0 end
        local skill = resolveStanceSkill(getActiveStance())
        if not skill then return nil, 0 end
        local bonus = math.floor(effectivenessSkillBonus(getActiveStance()) + 0.5)
        return skill, bonus
    end

    -- Native delta apply for one vanilla skill (mirrors perks setSkillContrib).
    local function setVanillaEffContrib(skillId, newContrib)
        local prev = effVanillaContrib[skillId] or 0
        if prev == newContrib then return end
        local stat = statAccess.getSkillStat(getSelf(), skillId)
        if not stat then return end
        local curMod = 0
        pcall(function() curMod = stat.modifier or 0 end)
        pcall(function() stat.modifier = curMod - prev + newContrib end)
        effVanillaContrib[skillId] = newContrib
    end

    -- Modded SF skills: keep the dynamic-modifier path (works for custom skills).
    local function computeBonusForSkill(skillId)
        local skill, bonus = currentEffectiveBonusSkill()
        if skill ~= skillId then return 0 end
        return bonus
    end

    local function ensureEffectivenessModifier(skillId)
        if not skillId then return end
        if effectivenessModifiersRegistered[skillId] then return end
        if not (I.SkillFramework
            and I.SkillFramework.registerDynamicModifier
            and I.SkillFramework.getSkillRecord) then return end
        local ok, rec = pcall(I.SkillFramework.getSkillRecord, skillId)
        if not ok or rec == nil then return end  -- skill not yet available
        local modId = 'Stance_SkillBonus_' .. skillId
        local sid = skillId
        local ok2 = pcall(I.SkillFramework.registerDynamicModifier, sid, modId,
            function() return computeBonusForSkill(sid) end)
        if ok2 then
            effectivenessModifiersRegistered[sid] = true
            debugLog(string.format('Effectiveness modifier registered on modded skill "%s"', sid),
                'debugIntegrationMessages')
        end
    end

    -- Called every update from init.lua. Applies the vanilla bonus natively to
    -- whichever skill the active stance targets (zeroing all others), and
    -- lazily registers SF modifiers for present modded skills.
    local function refreshEffectivenessModifiers()
        if not skillRegistered then return end

        local targetSkill, targetBonus = currentEffectiveBonusSkill()

        -- The Throwing! mod takes exclusive ownership of the vanilla `marksman`
        -- modifier whenever it is loaded: while a thrown weapon is equipped it
        -- rewrites marksman.modifier every tick to mirror the Throwing skill,
        -- and its bookkeeping treats ANY other downward write as a permanent
        -- external change. If Stance also writes marksman.modifier the two
        -- writers fight and ratchet marksman lower every frame. So when the
        -- throwing integration is present we never touch marksman here; the
        -- Twirler bonus is delivered to the `throwing` SF skill via the modded
        -- path below, and Throwing mirrors that onto marksman itself.
        local throwingOwnsMarksman = integrationPresent('throwing')

        -- Vanilla: set the target skill to its bonus, every other vanilla
        -- skill back to 0 (so swapping stances moves the bonus cleanly).
        for _, sid in ipairs(VANILLA_EFF_SKILLS) do
            if sid == 'marksman' and throwingOwnsMarksman then
                -- Release any contribution we previously owned (e.g. from
                -- Huntsman before Throwing loaded), then leave marksman alone.
                if (effVanillaContrib['marksman'] or 0) ~= 0 then
                    setVanillaEffContrib('marksman', 0)
                end
            elseif sid == targetSkill then
                setVanillaEffContrib(sid, targetBonus)
            else
                setVanillaEffContrib(sid, 0)
            end
        end

        -- Modded SF skills: register once when their integration is present.
        for intId, sfSkill in pairs(MODDED_EFF_SKILLS) do
            if integrationPresent(intId) then ensureEffectivenessModifier(sfSkill) end
        end
    end

    -- Clear our vanilla contributions (used on load/unregister so the engine's
    -- post-load zeroed modifiers aren't shadowed by a stale tracker).
    local function clearVanillaEffContribs()
        for _, sid in ipairs(VANILLA_EFF_SKILLS) do
            effVanillaContrib[sid] = 0
        end
    end

    local function syncSfToActiveStance()
        if not skillRegistered then return end
        if not (I.SkillFramework and I.SkillFramework.modifySkill) then return end

        local stanceId = getActiveStance() or 'commoner'
        local stance = getStanceConfig(stanceId)
        if not stance then return end

        local displayName = formatStanceName(stanceId)
        local attribute = stance.attribute or config.defaultAttribute
        if readSetting('', 'enableAttributeSwap', true) == false then
            attribute = config.defaultAttribute
        end

        -- ─── Tooltip ─────────────────────────────────────────────────────
        -- Layout:
        --   <lore description>
        --
        --   <Name>   <Attribute>            (mechanic toggle)
        --   Lv N   Core N   +N <Skill>      (mechanic toggle)
        --   N / N xp  (or Mastered)         (mechanic toggle)
        --
        --   [✓] Perk — Short description.
        --   [LvN] Perk — Short description.

        -- Friendly display names for all skill IDs used as bonus targets.
        -- Keeps the tooltip readable without exposing raw SF identifiers.
        local SKILL_LABEL = {
            longblade     = 'Long Blade',
            shortblade    = 'Short Blade',
            bluntweapon   = 'Blunt Weapon',
            axe           = 'Axe',
            spear         = 'Spear',
            marksman      = 'Marksman',
            handtohand    = 'Hand to Hand',
            block         = 'Block',
            armorer       = 'Armorer',
            security      = 'Security',
            speechcraft   = 'Speechcraft',
            mysticism     = 'Mysticism',
            throwing      = 'Throwing',
            staves_staves = 'Staves',
            fishing_skill = 'Fishing',
            mining_skill  = 'Mining',
        }

        local coreLevel = getCoreSkillLevel()
        local stLevel   = getStanceLevel(stanceId)
        local stXp      = getStanceXp(stanceId)
        local lines     = { stance.description }

        if readSetting('Tooltip', 'showMechanicTooltips', true) then
            local attrLabel   = attribute:sub(1, 1):upper() .. attribute:sub(2)
            local targetSkill = resolveStanceSkill(stanceId)
            local bonus       = targetSkill and math.floor(effectivenessSkillBonus(stanceId) + 0.5) or 0
            local skillLabel  = (targetSkill and SKILL_LABEL[targetSkill]) or targetSkill or 'none'
            local xpLine      = stLevel < config.maxLevel
                and string.format('%d / %d xp', math.floor(stXp), math.floor(xpForStanceLevel(stLevel)))
                or  'Mastered'

            table.insert(lines, '')
            table.insert(lines, string.format('%s   %s', stance.displayName, attrLabel))
            table.insert(lines, string.format('Lv %d   Core %d   +%d %s', stLevel, coreLevel, bonus, skillLabel))
            table.insert(lines, xpLine)
        end

        -- Perks: name + short description only; no verbose sub-headers.
        if readSetting('Tooltip', 'showPerkTooltips', true) and perksEnabledForStance(stanceId) then
            local unlockedOnly = readSetting('Tooltip', 'tooltipUnlockedOnly', false)
            local first = true
            for _, perk in ipairs(stance.perks) do
                local unlocked = coreLevel >= perk.level
                if unlocked or not unlockedOnly then
                    if first then table.insert(lines, ''); first = false end
                    local marker = unlocked and '✓' or ('Lv' .. perk.level)
                    table.insert(lines, string.format('  [%s] %s — %s',
                        marker, perk.name, perk.description))
                end
            end
        end

        local description = table.concat(lines, '\n')

        -- Each modifySkill field is wrapped in its own pcall so older SF
        -- versions that only accept `description` still get the most
        -- important update without rejecting the whole call.
        local function tryModify(field, value, cached)
            if value == cached then return cached end
            local ok, err = pcall(I.SkillFramework.modifySkill, SKILL_ID, { [field] = value })
            if ok then return value end
            debugLog(string.format('modifySkill failed for field "%s": %s', field, tostring(err)),
                'debugIntegrationMessages')
            return cached
        end

        lastSkillSyncedDescription = tryModify('description', description, lastSkillSyncedDescription)
        lastSkillSyncedName        = tryModify('name', displayName, lastSkillSyncedName)
        lastSkillSyncedAttribute   = tryModify('attribute', attribute, lastSkillSyncedAttribute)
    end

    -- Reset the registration flags. Matches what init.lua's onLoad and the
    -- console "reload" command used to do inline (the 5 flags; the
    -- effectiveness-modifier registry is intentionally NOT reset, exactly as
    -- before).
    local function markUnregistered()
        skillRegistered = false
        classBonusApplied = false
        lastSkillSyncedName = nil
        lastSkillSyncedAttribute = nil
        lastSkillSyncedDescription = nil
        -- The engine zeroes skill modifiers on load. Drop our tracked vanilla
        -- effectiveness contributions to 0 so the next refresh re-applies the
        -- real bonus onto the freshly-zeroed modifier instead of believing it
        -- is already present (prev == new) and skipping it.
        clearVanillaEffContribs()
    end

    return {
        isSkillRegistered          = function() return skillRegistered end,
        isClassBonusApplied        = function() return classBonusApplied end,
        registerSkill              = registerSkill,
        applyClassBonus            = applyClassBonus,
        refreshEffectivenessModifiers = refreshEffectivenessModifiers,
        syncToActiveStance         = syncSfToActiveStance,
        markUnregistered           = markUnregistered,
    }
end

return M
