--[[
    Stance! — Config

    Central tuning file. All numerical values, stance definitions, perk
    ladders, and integration table-driven settings live here.

    The mod is built around a registry of "stances". Every stance has:
      * a stable internal id (used as storage key, lowercase, ASCII)
      * a display name (the user-facing label)
      * a governing attribute (the attribute the stance scales with)
      * a description (a 1-2 sentence stance summary)
      * an effectiveness category
      * a list of integration ids the stance prefers to interlope with
      * a perk ladder (25/50/75/100). Where a stance has an associated mod,
        the perks reuse / amplify the source mod's existing perk catalog so
        both mods feel cohesive when running together. Stances without an
        associated mod get net-new perks that fit the stance's theme.

    Inspired by For Honor's stance system — when you change weapons mid-
    fight, the game treats you as a different combatant entirely. Stance!
    reproduces that feel by giving each weapon style its own independent
    skill level, its own perk ladder, and its own attribute scaling, all
    surfaced through a single Skill Framework entry that morphs in real
    time as you change weapons.

    Detection priority (first match wins):
       1) Locksmith    — lockpick OR probe equipped (any weapon stance)
       2) Commoner     — sheathed (no lockpick/probe — Locksmith fallback)
       3) Arcanist     — spellcasting stance active
       4) Reforger     — armorer's repair hammer equipped, weapon stance up
       5) Blademeister — Felthorn (any sd_-prefixed weapon form) equipped
       6) Huntsman     — bow or crossbow equipped
       7) Twirler      — thrown weapon equipped
       8) Thaumaturge  — stave (BluntTwoWide) equipped
       9) Dualist      — Dual Wielding off-hand event active (any 1H melee primary)
      10) Fortifier    — a shield is equipped (regardless of weapon)
      11) Guisarmier   — spear (SpearTwoWide)
      12) Axeman       — axe of either size (AxeOneHand or AxeTwoHand)
      13) Zweihänder   — long-blade two-handed weapon (LongBladeTwoHand)
      14) Soloist      — long-blade one-handed weapon (LongBladeOneHand)
      15) Thief        — short blade (ShortBladeOneHand)
      16) Brawler      — unarmed, right hand truly empty, weapon stance up
      17) Commoner     — final fallback

    Non-listed melee weapons (one-handed blunts, two-handed blunts that
    aren't staves, etc.) intentionally fall through to Commoner unless a
    higher-priority branch claims them — Fortifier with a shield, Dualist
    with a second weapon, Reforger with the hammer, Blademeister with
    Felthorn, and so on.

    No prefixes. No combination stances. No GRIP-conversion-based stances —
    the conversion records aren't reliably available across save/load
    cycles, so classification is by raw weapon type instead.
]]

local config = {
    -- ─── Skill Framework registration ──────────────────────────────────────
    skillId = 'stance',
    defaultDisplayName = 'Stance',
    defaultAttribute = 'luck',
    startLevel = 5,
    maxLevel = 100,
    classBonus = 10,

    -- ─── Leveling ─────────────────────────────────────────────────────────
    -- Per-stance progression with a shared core skill:
    --   * Each stance has its OWN xp bank and level (5 → 100), persisted in
    --     player storage. Only the ACTIVE stance gains xp; switching stances
    --     banks the current one untouched.
    --   * The core "Stance" skill (owned by Skill Framework) gains HALF of
    --     whatever the active stance just gained, and levels independently.
    --     So each stance levels roughly twice as fast as the core skill.
    --   * PERKS unlock from the CORE skill level: at core level 25 every
    --     stance's level-25 perk becomes available, and so on for 50/75/100.
    --   * A stance's OWN level scales its EFFECTIVENESS multiplier (see
    --     `leveling.effectiveness*` below) — a smooth ramp from 1.0 at the
    --     start level to effectivenessMax at level 100. This is surfaced in
    --     the tooltip and exposed on the script interface for other systems.
    leveling = {
        baseXpToLevel  = 8,     -- flat base xp for the first stance level-up
        xpRampPerLevel = 0.06,  -- +6% required xp per level above startLevel
        maxXpToLevel   = 400,   -- hard cap on per-level xp requirement
        -- Effectiveness ramp driven by the active stance's own level.
        effectivenessMax = 1.50, -- 1.0 at startLevel → 1.50 at maxLevel
    },

    -- ─── XP source weights ────────────────────────────────────────────────
    -- Each successful action grants this much xp to the ACTIVE stance,
    -- before the global xpMultiplier setting is applied. The core Stance
    -- skill simultaneously receives half of that scaled amount.
    xp = {
        combatHit             = 1.00,
        combatKill            = 2.00,
        spellCast             = 0.80,
        blockSuccess          = 1.20,
        stanceTimeTick        = 0.10,
        stanceTimeIntervalSec = 10.0,
        meditateTick          = 0.40,
        merchantTransaction   = 1.50,
        -- Reforger: granted whenever the player successfully upgrades a
        -- weapon or piece of armor with the Weapon/Armor Upgrade mods.
        upgradeSuccess        = 4.00,
        upgradeFailure        = 0.50,  -- a failed attempt still teaches you
    },

    -- ─── Stance definitions ───────────────────────────────────────────────
    stances = {
        {
            id = 'arcanist',
            displayName = 'Arcanist',
            attribute = 'intelligence',
            description = 'Channel of the arcane. In spellcasting stance your spells flow more freely and meditation sharpens your focus.',
            integrations = { 'incantation', 'meditation' },
            category = 'magic',
            -- Reuses the spellcasting catalysts Incantation and Meditation
            -- Skill already offer. Incantation refunds magicka on custom
            -- spells; Meditation grants Willpower-based passive magicka
            -- regeneration. These perks layer on top of those.
            perks = {
                {
                    level = 25, id = 'focusedChant', name = 'Focused Chant',
                    description = 'Spell magicka cost is reduced by 5% while in Arcanist stance.',
                },
                {
                    level = 50, id = 'meditatedMind', name = 'Meditated Mind',
                    description = 'Passive magicka regeneration (from Meditation Skill) is boosted by 25% while in Arcanist stance.',
                },
                {
                    level = 75, id = 'incantedFocus', name = 'Incanted Focus',
                    description = 'Custom-spell magicka refunds (from Incantation) gain a 10% additive bonus while in Arcanist stance.',
                },
                {
                    level = 100, id = 'aetherealMind', name = 'Aethereal Mind',
                    description = 'Spell failure chance is halved while Arcanist stance is active.',
                },
            },
        },

        {
            id = 'reforger',
            displayName = 'Reforger',
            attribute = 'endurance',
            description = "The armorer's hammer is your wand AND your weapon. While the repair hammer is in hand you swing with surer arms — perks tilt the hammer's weight onto your enemies, exploiting the same weak points you'd patch at the anvil.",
            integrations = { 'weaponupgrade', 'armorupgrade' },
            category = 'damage',
            -- Combat-themed perks. The Reforger archetype knows metal: they
            -- know where armor is structurally weakest, how to dent it with
            -- a hammer, and they've got steady arms from working a forge.
            -- All four perks fire only when the player is in Reforger
            -- stance (i.e. the repair hammer is in their right hand).
            perks = {
                {
                    level = 25, id = 'anvilArms', name = 'Anvil Arms',
                    description = 'Fatigue drain from hammer swings is reduced by 15% while in Reforger stance — conditioning from long hours at the forge.',
                },
                {
                    level = 50, id = 'weakPointStrike', name = 'Weak-Point Strike',
                    description = "Hammer hits ignore 10% of the target's armor while in Reforger stance — you know where the rivets are.",
                },
                {
                    level = 75, id = 'sunderingBlow', name = 'Sundering Blow',
                    description = "Each hammer hit has a 10% chance to also damage the target's equipped armor condition — the hammer dents armor like it would at the anvil.",
                },
                {
                    level = 100, id = 'forgemastersTouch', name = "Forgemaster's Touch",
                    description = '+25% damage with the repair hammer, and power-attack hits gain a +20% chance to stagger the target.',
                },
            },
        },

        {
            id = 'blademeister',
            displayName = 'Blademeister',
            attribute = 'agility',
            description = 'You are the meister; Felthorn is the weapon. Together you hunt evil souls. While Felthorn — in any of its shapeshifted forms — is in your hand, your soul resonates with the Daedra blade and you both grow stronger with every soul collected. Inspired by Maka Albarn and Soul Eater Evans.',
            integrations = { 'blademeister' },
            category = 'damage',
            -- Soul Eater themed perks. The pact between meister and weapon
            -- is what drives the stance — each perk reflects a stage of
            -- their growing partnership. The capstone is Soul Resonance,
            -- the show's signature super-move. Witch Hunter (the move it
            -- produces in canon) is folded into the level 75 perk so the
            -- progression mirrors the anime's arc: foundation, partnership,
            -- finisher, peak resonance.
            --
            -- The stance is governed by Agility because Maka is the
            -- protagonist's scythe-meister archetype: nimble, precise,
            -- footwork-focused — not a Strength bruiser. (Felthorn rapier
            -- forms are LongBlade, claymore forms are LongBlade 2H, etc.
            -- — the underlying weapon type varies, but the meister's
            -- identity does not.)
            perks = {
                {
                    level = 25, id = 'soulPerception', name = 'Soul Perception',
                    description = "Maka's gift — see the souls others cannot. +5 effective Sneak and +5 effective Mysticism while Felthorn is in hand.",
                },
                {
                    level = 50, id = 'soulWavelength', name = 'Soul Wavelength',
                    description = 'Your wavelength flows into the blade. +15% weapon damage with Felthorn and a +10% chance for hits to briefly disrupt the target.',
                },
                {
                    level = 75, id = 'witchHunter', name = 'Witch Hunter',
                    description = 'The pact resonates into a finishing move. Power attacks with Felthorn deal +30% damage and have a 15% chance to strike twice.',
                },
                {
                    level = 100, id = 'soulResonance', name = 'Soul Resonance',
                    description = 'Meister and weapon as one. +25% weapon damage, +10% attack speed with Felthorn, and the blade ignores 10% of the target armor.',
                },
            },
        },

        {
            id = 'huntsman',
            displayName = 'Huntsman',
            attribute = 'speed',
            description = 'Hunter of the wild. Bow and crossbow draws are quicker and your ranged volleys hit harder.',
            integrations = { 'bullseye' },
            category = 'ranged',
            -- Bullseye's signature feature is the headshot kill on
            -- creatures in its whitelist. Stance!'s Huntsman perks extend
            -- that catalyst with fatigue drain, slow, and a damage bonus.
            perks = {
                {
                    level = 25, id = 'steadyAim', name = 'Steady Aim',
                    description = 'Bow and crossbow fatigue drain reduced by 15% while in Huntsman stance.',
                },
                {
                    level = 50, id = 'pinningShot', name = 'Pinning Shot',
                    description = 'Ranged hits briefly slow the target for 1.5 seconds.',
                },
                {
                    level = 75, id = 'concussiveShot', name = 'Concussive Shot',
                    description = 'A Bullseye headshot also drains 25 fatigue from the target.',
                },
                {
                    level = 100, id = 'killshot', name = 'Killshot',
                    description = 'Ranged headshots (Bullseye) deal +25% damage while in Huntsman stance.',
                },
            },
        },

        {
            id = 'twirler',
            displayName = 'Twirler',
            attribute = 'agility',
            description = 'A whirlwind of thrown steel. Throws fly faster, land harder, and recover quicker.',
            integrations = { 'throwing' },
            category = 'ranged',
            -- Mirrors Throwing!'s own four perks: Critical (25), Twin
            -- Flight (50), Bleed (75), Paralyze (100). Each Twirler perk
            -- amplifies the matching Throwing! perk only while in stance.
            perks = {
                {
                    level = 25, id = 'edgedSpin', name = 'Edged Spin',
                    description = 'Throwing! Critical chance gains an additive +3% while in Twirler stance.',
                },
                {
                    level = 50, id = 'twinedThrow', name = 'Twinned Throw',
                    description = 'Throwing! Twin Flight chance gains an additive +5% while in Twirler stance.',
                },
                {
                    level = 75, id = 'rendingHand', name = 'Rending Hand',
                    description = 'Throwing! Bleed magnitude gains a +1 floor while in Twirler stance.',
                },
                {
                    level = 100, id = 'whirlwindArm', name = 'Whirlwind Arm',
                    description = 'Throwing! Paralyze duration gains +1 second while in Twirler stance.',
                },
            },
        },

        {
            id = 'thaumaturge',
            displayName = 'Thaumaturge',
            attribute = 'willpower',
            description = 'A stave is more than a stick — it is a wand made into a weapon. Stave swings draw on willpower and bend magic to your purpose.',
            integrations = { 'staves' },
            category = 'magic',
            -- Mirrors Staves!'s own four perks: Concussive Strike (25),
            -- Arcane Siphon (50), Resonant Conduit (75), Null Pulse (100).
            -- Each Thaumaturge perk amplifies the matching Staves! perk
            -- only while in stance.
            perks = {
                {
                    level = 25, id = 'concussiveAccord', name = 'Concussive Accord',
                    description = 'Staves! Concussive Strike chance gains an additive +10% while in Thaumaturge stance.',
                },
                {
                    level = 50, id = 'siphonedAccord', name = 'Siphoned Accord',
                    description = 'Staves! Arcane Siphon chance gains an additive +5% while in Thaumaturge stance.',
                },
                {
                    level = 75, id = 'resonantAccord', name = 'Resonant Accord',
                    description = 'Staves! Resonant Conduit chance gains an additive +3% while in Thaumaturge stance.',
                },
                {
                    level = 100, id = 'pulsedAccord', name = 'Pulsed Accord',
                    description = 'Staves! Null Pulse silence duration gains +2 seconds while in Thaumaturge stance.',
                },
            },
        },

        {
            id = 'dualist',
            displayName = 'Dualist',
            attribute = 'speed',
            description = 'Two blades, one mind. Dual wielding rewards quick footwork and matched timing.',
            integrations = { 'dualwielding' },
            category = 'speed',
            -- Dual Wielding doesn't ship a perk system, so these are
            -- net-new perks built around what the mod actually does: a
            -- second weapon in the off hand with its own enchantment
            -- charge, and the OnStrikesetCharge event the mod uses.
            perks = {
                {
                    level = 25, id = 'lightFootwork', name = 'Light Footwork',
                    description = '+10% movement speed while a second weapon is mounted.',
                },
                {
                    level = 50, id = 'mirrorEdge', name = 'Mirror Edge',
                    description = 'Off-hand weapon strikes deal +15% damage in stance.',
                },
                {
                    level = 75, id = 'twinTempo', name = 'Twin Tempo',
                    description = '+15% attack speed while dual-wielding.',
                },
                {
                    level = 100, id = 'crossGuard', name = 'Cross Guard',
                    description = "While dual-wielding, you parry and block as if a shield were equipped (uses N'Garde parry effectiveness when present).",
                },
            },
        },

        {
            id = 'fortifier',
            displayName = 'Fortifier',
            attribute = 'strength',
            description = "Sword and board, or simply the board. A shield in the off-hand changes everything — the stance triggers any time you've got a shield equipped, regardless of what's in the other hand.",
            integrations = { 'ngarde' },
            category = 'block',
            -- N'Garde adds an active parry and a perfect-parry reaction
            -- window. Fortifier perks specifically widen the parry window,
            -- buff the perfect parry, and add a panic-block once-per-30s
            -- safety net.
            perks = {
                {
                    level = 25, id = 'shieldUp', name = 'Shield Up',
                    description = 'Block effectiveness increased by 10% while in Fortifier stance.',
                },
                {
                    level = 50, id = 'wardenStance', name = 'Warden Stance',
                    description = "N'Garde parry window is widened by 25% while in Fortifier stance.",
                },
                {
                    level = 75, id = 'perfectGuard', name = 'Perfect Guard',
                    description = "N'Garde perfect-parry damage rebound gains +20% while in Fortifier stance.",
                },
                {
                    level = 100, id = 'bulwark', name = 'Bulwark',
                    description = 'Once per 30 seconds, a hit you would have taken is fully blocked instead.',
                },
            },
        },

        {
            id = 'zweihander',
            displayName = 'Zweihänder',
            attribute = 'strength',
            description = 'A two-handed long blade — the dueling sword answered in kind. Slow, heavy, and ruinous when it lands. Other two-handed weapons (axes, blunts, spears) do not qualify for this stance.',
            integrations = {},
            category = 'damage',
            perks = {
                {
                    level = 25, id = 'twoHandGrip', name = 'Two-Hand Grip',
                    description = '+10% damage with two-handed weapons while in Zweihänder stance.',
                },
                {
                    level = 50, id = 'sweepingArc', name = 'Sweeping Arc',
                    description = '+15% chance for an attack to also hit a second nearby enemy in melee range.',
                },
                {
                    level = 75, id = 'cleavingBlow', name = 'Cleaving Blow',
                    description = "+10% chance for hits to ignore a portion of the target's armor.",
                },
                {
                    level = 100, id = 'titanGrip', name = 'Titan Grip',
                    description = '+25% damage with two-handed weapons and fatigue drain from heavy weapons is halved.',
                },
            },
        },

        {
            id = 'guisarmier',
            displayName = 'Guisarmier',
            attribute = 'endurance',
            description = "Long reach, sharp point. The polearm wielder keeps the enemy at spear's length, where a measured thrust does the work of three wild swings.",
            integrations = {},
            category = 'damage',
            -- Spear-themed perks. Spear is governed by Endurance in vanilla
            -- Morrowind, so the attribute swap aligns with what the player
            -- already expects from the weapon skill.
            perks = {
                {
                    level = 25, id = 'reachAdvantage', name = 'Reach Advantage',
                    description = '+10% damage with spears while in Guisarmier stance — the long haft turns range into damage.',
                },
                {
                    level = 50, id = 'phalanxBrace', name = 'Phalanx Brace',
                    description = 'Knockdown resistance is increased by 25% while in Guisarmier stance — a set spear can stop a charge.',
                },
                {
                    level = 75, id = 'pinningThrust', name = 'Pinning Thrust',
                    description = 'Spear hits have a +10% chance to briefly slow the target — a wound to the leg slows the foot.',
                },
                {
                    level = 100, id = 'polearmMaster', name = 'Polearm Master',
                    description = '+25% damage with spears, and fatigue drain from spear attacks is reduced by 20%.',
                },
            },
        },

        {
            id = 'axeman',
            displayName = 'Axeman',
            attribute = 'strength',
            description = 'Axe in hand, no subtlety required. Whether the haft is short or long, the head does the talking — cleave deep, cleave again.',
            integrations = {},
            category = 'damage',
            -- Axe-themed perks. Triggers for both AxeOneHand and
            -- AxeTwoHand because the user explicitly said "for having
            -- axes equipped" without qualifying one-handed vs two-handed.
            perks = {
                {
                    level = 25, id = 'cleavingEdge', name = 'Cleaving Edge',
                    description = '+10% damage with axes while in Axeman stance.',
                },
                {
                    level = 50, id = 'heavyChop', name = 'Heavy Chop',
                    description = '+20% damage on axe power attacks while in Axeman stance.',
                },
                {
                    level = 75, id = 'bleedingCut', name = 'Bleeding Cut',
                    description = 'Axe hits cause a small bleed effect on the target — 1 health drained per second for 5 seconds.',
                },
                {
                    level = 100, id = 'headsman', name = 'Headsman',
                    description = "+25% damage with axes, and axe hits have a 10% chance to ignore a portion of the target's armor.",
                },
            },
        },

        {
            id = 'soloist',
            displayName = 'Soloist',
            attribute = 'endurance',
            description = 'A one-handed long blade, no shield, no second hand. Just you, your saber, and the line. Other one-handed weapons (short blades, blunts, axes) do not qualify for this stance.',
            integrations = {},
            category = 'damage',
            perks = {
                {
                    level = 25, id = 'plantedFeet', name = 'Planted Feet',
                    description = 'Knockdown resistance increased by 25% while in Soloist stance.',
                },
                {
                    level = 50, id = 'heavyHand', name = 'Heavy Hand',
                    description = '+15% damage on power attacks with a one-handed weapon.',
                },
                {
                    level = 75, id = 'unstoppable', name = 'Unstoppable',
                    description = '+10% chance for hits to stagger their target while in Soloist stance.',
                },
                {
                    level = 100, id = 'solitaryWill', name = 'Solitary Will',
                    description = '+15 effective Endurance while in Soloist stance.',
                },
            },
        },

        {
            id = 'thief',
            displayName = 'Thief',
            attribute = 'speed',
            description = 'A short blade slips between ribs where a longer one would clatter against bone. Quick steps, quicker cuts, and a knack for being elsewhere when blame lands.',
            integrations = {},
            category = 'speed',
            -- Short-blade-themed perks. Speed is the vanilla governing
            -- attribute for Short Blade in Morrowind, so the attribute
            -- swap aligns with what the player already feels from the
            -- weapon skill.
            perks = {
                {
                    level = 25, id = 'quickStrike', name = 'Quick Strike',
                    description = '+10% attack speed with short blades while in Thief stance.',
                },
                {
                    level = 50, id = 'cutpurse', name = 'Cutpurse',
                    description = '+5 effective Sneak skill while in Thief stance.',
                },
                {
                    level = 75, id = 'backstab', name = 'Backstab',
                    description = '+25% bonus damage from short blade hits delivered from behind a target.',
                },
                {
                    level = 100, id = 'masterThief', name = 'Master Thief',
                    description = '+25% damage with short blades, and +10% movement speed while in Thief stance.',
                },
            },
        },

        {
            id = 'locksmith',
            displayName = 'Locksmith',
            attribute = 'agility',
            description = 'Tools in pouch, eye on the keyhole. The careful exploration stance — active when your weapons are sheathed AND you have lockpicks AND probes on hand for the work.',
            integrations = {},
            category = 'utility',
            -- Lockpick/probe-themed perks. Triggers only when the player
            -- is sheathed AND carries both lockpicks and probes — it's a
            -- specialisation of the non-combat Commoner state. Governed
            -- by Agility because Security (the vanilla skill these tools
            -- use) is also governed by Agility.
            perks = {
                {
                    level = 25, id = 'lightFingers', name = 'Light Fingers',
                    description = '+5 effective Security skill while in Locksmith stance.',
                },
                {
                    level = 50, id = 'probeSage', name = 'Probe Sage',
                    description = 'Probes are 10% less likely to break on use while in Locksmith stance.',
                },
                {
                    level = 75, id = 'sneakStep', name = 'Sneak Step',
                    description = '+5 effective Sneak skill while in Locksmith stance.',
                },
                {
                    level = 100, id = 'masterOfLocks', name = 'Master of Locks',
                    description = 'Lock difficulty is treated as 15 points lower while in Locksmith stance — the toughest tumblers feel like beginner work.',
                },
            },
        },

        {
            id = 'brawler',
            displayName = 'Brawler',
            attribute = 'strength',
            description = 'Bare hands and steady fists. Hand-to-hand strikes hit harder and your stamina lasts longer in the clinch.',
            integrations = { 'gothicknockout' },
            category = 'fatigue',
            -- GSK's signature is the non-lethal knockdown. Brawler perks
            -- center on knockdown frequency and on the fatigue cost that
            -- unarmed combat normally suffers from.
            perks = {
                {
                    level = 25, id = 'ironGrip', name = 'Iron Grip',
                    description = '+15% Hand-to-Hand damage while in Brawler stance.',
                },
                {
                    level = 50, id = 'closeRangeFighter', name = 'Close-Range Fighter',
                    description = 'Fatigue drain from unarmed attacks reduced by 25%.',
                },
                {
                    level = 75, id = 'concussiveJab', name = 'Concussive Jab',
                    description = '+10% chance for unarmed hits to knock the target down via Gothic Style Knockout.',
                },
                {
                    level = 100, id = 'streetMaster', name = 'Street Master',
                    description = 'Each successful unarmed hit briefly restores fatigue.',
                },
            },
        },

        {
            id = 'commoner',
            displayName = 'Commoner',
            attribute = 'luck',
            description = 'Weapons sheathed, fists at rest, magic uncast. The everyday adventurer who haggles, charms, and walks softly.',
            integrations = {},
            category = 'social',
            perks = {
                {
                    level = 25, id = 'merchantsEye', name = "Merchant's Eye",
                    description = 'Mercantile checks gain a small Luck-based bonus.',
                },
                {
                    level = 50, id = 'silverTongue', name = 'Silver Tongue',
                    description = 'Speechcraft effectiveness increased by 10%.',
                },
                {
                    level = 75, id = 'urbanCharm', name = 'Urban Charm',
                    description = 'Disposition gains from successful Admire are improved.',
                },
                {
                    level = 100, id = 'thePeoplesHero', name = "The People's Hero",
                    description = 'Better prices in barter and faster disposition recovery between conversations.',
                },
            },
        },
    },

    -- ─── Integration / external mod detection ─────────────────────────────
    -- Detection probes in order of preference:
    --   1) Skill Framework skill registered with `skillId` below
    --   2) Global storage section `storageSection` is non-empty
    --   3) Settings group `settingsGroup` is non-empty (used by mods that
    --      don't expose a SF skill but do register a settings page)
    --   4) Public event listed in `event` has fired recently
    integrations = {
        toxicology = {
            label = 'Toxicology!',
            skillId = 'toxicology',
            storageSection = 'Runtime_Toxicology',
        },
        throwing = {
            label = 'Throwing!',
            skillId = 'throwing',
            storageSection = 'Runtime_Throwing',
        },
        staves = {
            label = 'Staves!',
            skillId = 'staves_staves',
            storageSection = 'Runtime_Staves',
        },
        meditation = {
            label = 'Meditation Skill',
            skillId = 'meditation_skill',
        },
        incantation = {
            label = 'Incantation',
            skillId = 'incantation_skill',
        },
        bullseye = {
            label = 'Bullseye',
            settingsGroup = 'SettingsBullseye',
        },
        ngarde = {
            label = "N'Garde",
            event = 'ngarde_ParrySuccess',
        },
        dualwielding = {
            label = 'Dual Wielding',
            event = 'EquipSecondWeapon',
            settingsGroup = 'DualWieldingscontrols',
        },
        gothicknockout = {
            label = 'Gothic Style Knockout',
            settingsGroup = 'SettingsGKD',
            event = 'GKD_DoKnockdown',
        },
        weaponupgrade = {
            label = 'WeaponUpgrade',
            settingsGroup = 'SettingsWeaponUpgrade',
        },
        armorupgrade = {
            label = 'ArmorUpgrade',
            settingsGroup = 'SettingsArmorUpgrade',
        },
        grip = {
            label = 'GRIP',
            -- GRIP doesn't register a Skill Framework skill or fire a
            -- detectable global event during normal play. Its canonical
            -- signal is the 'GRIPRecords' global storage section, which
            -- the mod always writes during onInit even before the player
            -- swaps any weapon. (WeaponUpgrade uses the same probe.)
            storageSection = 'GRIPRecords',
        },
        blademeister = {
            label = 'Blademeister',
            -- Blademeister has no Skill Framework skill, no global storage
            -- section, no public event hookups. Its presence is detected
            -- indirectly: when the player equips any weapon whose record
            -- id starts with the `sd_` prefix, the mod is necessarily
            -- loaded (the engine couldn't have spawned that record
            -- otherwise). So integration presence is checked by
            -- consulting types.Weapon.records for at least one record
            -- whose id starts with `sd_`. See init.lua's detectIntegration.
            recordIdPrefix = 'sd_',
        },
    },

    -- The Reforger stance's detection trigger. Both WeaponUpgrade and
    -- ArmorUpgrade gate their behavior on the player holding this exact
    -- record id, so this is the canonical signal.
    reforgerHammerRecordId = 'repair_hammer_weapon',

    -- The Blademeister (Soul Eater) stance's detection trigger. Felthorn,
    -- the shapeshifting Daedra weapon from the Blademeister mod, doesn't
    -- have one canonical record id — instead the mod defines 180+ weapon
    -- records (one per material × form × tier) all sharing the `sd_`
    -- prefix that the mod author uses for every Felthorn shape.
    -- Examples: sd_IronRapier0, sd_DaedricClaymore4, sd_CatgirlRapier,
    -- sd_SaintSword2, sd_DremoraAxe1, sd_GlassLongsword3.
    -- A simple prefix match catches every form Felthorn can take, and
    -- since Blademeister is the only Morrowind mod using `sd_` for weapon
    -- records (verified by scanning the ESP — all 181 weapons in the mod
    -- use this prefix and nothing else does), false positives in a
    -- standard load order are vanishingly rare.
    blademeisterRecordPrefix = 'sd_',

    -- ─── Stance change debounce ───────────────────────────────────────────
    stanceChangeDebounceSec = 0.35,

    -- ─── Detection polling cadence ────────────────────────────────────────
    pollIntervalSec = 0.25,

    -- ─── UI ───────────────────────────────────────────────────────────────
    ui = {
        tooltipStanceColor = { 0.92, 0.85, 0.55 },
        tooltipPerkColor   = { 0.85, 0.85, 0.85 },
        messageDuration    = 3.0,
        hudIconSize        = 22,
    },

    -- ─── Debug ────────────────────────────────────────────────────────────
    debug = {
        defaultDebug = false,
    },
}

return config
